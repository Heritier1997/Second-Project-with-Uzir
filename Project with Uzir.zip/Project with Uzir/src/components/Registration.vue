<template>
    
    <div class="container-fluid d-flex justify-content-center mt-3">

        <!-- Card starts here -->
        <div class="card col-md-6 border-0 bg-light pt-3 pb-5"  style="border-radius:50px;">
            
            <!-- Card header -->
            <div class="card-header bg-light border-0 text-center mb-5">
                <img class="img-fluid" src="https://upload.wikimedia.org/wikipedia/en/c/ce/Google_account_icon.svg" width="100" height="100" />
                <h3 class="mt-2 display-3 text-dark">Create Account</h3>
            </div>
            <!-- End Card header -->

            <!-- Card Body -->
            <div class="card-body bg-light border-0 px-5">
                        
                <form class="form text-white">
                    
                    <div>
                        <input type="text" class="form-control bg-light 
                        inputField input-xxlarge" placeholder="First Name:" 
                        v-model="firstname"><br><br>
                        <input type="text" class="form-control bg-light inputField"
                         placeholder="Last Name:"
                         v-model="lastname"><br><br>
                        <br>
                        <label for="file" class="text-silver"><h2>&nbsp;
                            Select an image</h2></label><br>
                        <input type="file" name="file" id="picture" />
                    </div>

                    <div class="mt-5 text-center">
                        <button class="btn btn-lg px-5 btn-primary btnStep"
                        @click.prevent="add">
                            Submit</button>&nbsp;
                        <button class="btn btn-lg px-5 btn-danger btnStep"
                        @click.prevent="reset">
                            Reset</button>
                    </div>

                </form>

            </div>
            <!-- End Card Body -->

        </div>

    </div>

</template>

<script>
export default {
    name:'registration',
    props: ['students'],
    data(){
        return{
            firstname: '',
            lastname: '',
            pic: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAZlBMVEX///9RUVFOTk5nZ2fc3NxMTExISEj8/PxGRkbj4+Py8vJBQUFZWVn29vbs7Oz4+PjMzMx+fn6+vr6Ghobn5+diYmKdnZ14eHiVlZVvb29YWFiPj4/Y2Nitra24uLilpaW0tLTIyMhz1MHBAAAIwklEQVR4nO2d65qqOgyGp4FyEhEFBARP93+TG2fNHgFRaZtImIf394z2szTNoQ1fXwsLCwsLCwsLCwstNr5dx9drHNd2MPVY8EmvxyLJSytrsMpyW51P9dRjQiQ6JVYoQMIvUopDVp7/hkg3zkWjSTxwU5odZ/+8BidrJR/V/ar0oPA3Uw/SgOiaeQOz18Fx9qk79UA1WceJfKfvW6N1SaceqxbpPnzxfHZX5Dae4TTG+ZB5eYLMjrNbjedwvL7bNIptNPWQ1ahGrcCOxnBOizHajlyB3WmMpx73aHwdgbdZ3M3E3vhbR0dgIzGbh8Q00ZrBG9K6zkBioC/wJnEGa9FE4G1jZG9Rj5pr8D6LUyt4Q6y6DT7gVFNreIlvGSsUcJpaxQvWlblAAZY9tY7n7NSc0WcSq/XUQp7h50Z29FdhuJtayRM2Z4wZbJC5P7WWYewDkkIhjyxdm01luBXegYzlJNoelkAhvDPHSdQLmYaBA8NJtFd4AhvPZj+1nkfMPO5H2O2JEZoh/YfHznc74gpsfLepFfVwS2SFApjFwlcUj7SjkFkUtccWKKBkZWsCzM3wR2F4nVpVmxgh8n2A1ZaIbUlvyC2j+vC6QH9IbwuRUZnfzwnmUHAKhOOMQqFznlrXnR3BQ9osxIrNQtyc0WLfNpCzSbpFFckcQsbG1KRbimUoxIHNno+R6R7CYWNM7QOJQOFcuGRrasQcVEfhnovzfSVSKCsmJ1DcHZXChIvCE8l2ePO9mRSEXdO67zOAi0Iil+bm1Px5hSWTzPffV0i3DtkovPz1deieiPZDNrb068/v+F8xamGtpZBNkF+TBMCcPG8bvWjxo5DNgQUfvfD0o5BNBJziVy3+wSaLEVCkvG+ZKDYlRCKnhlE2kSojzGY7bDZEEmPq7LmY0ma7IKnMwHFqXXcCiqQ3ZGxMacOZpH7Ix9A0poYgJywTThf2agKvBljV8TfYp9oErxJwwxldIFhcwt9/EJyJ2k6tqUuAf66N0W74TYFuapjk2X4xv/DUhd3py68v5AMnDreH9OtrjxtBeXziiv/xURNukE+tZwBUa7ri5HX/D2atGzIumdI2a8QzJw7LOzOIBRoIOQVOd3y0DcMpOD6kzWOKVinlc9yrR420EvlUZPq4SLv+gVdk2AZnEmXCdQq/cC6WMLto0cNGcGwg4bYX1u1ADuHixaF1Mjhm0AMsuljtK1hr40l0ivunpXl4nnjvd6+JkFl7ELVpiAEtM3MS4JTHKeOotLgloLqJzcRsx1i17o5+dysCkU9XRryE303nuul3s+uycttKdP8U7UDsp8l+279dH7tlsFroS+y0GrgfD3DCCe4lbHb3poFgtQdg1B7jdP+t3Ms94ITV5dMHT4Jze6a6B18i7RQ/tGOKbqgiq89mF/2q8yhC2DEGunUa6PQ06bXZgPyTe2Pcr/nKbXsSXb1OPN2zF9e+TZbW5/rVnbKHx1B2GgS4Rw2BzSJsfcT6MZyG8FM51POAsQToxgOVelrK62yrQ3VzEJ+5wV4MNu6UZfevlBsqyaT975cnv0LyRY77rFIoL92/S9SWYjeieBqjSPIuWZvjM5elf1swqBR2/ub5az/lL/YbIE5SuZfnVrJ/ZjkqRksEUbTd6/X+1Z/uSSWeXm4DvQOvwZBJGjFq9/TKtYUDZVPl1/scHE7dDWv9cqj3/4OuS/bmDBkc6K4lvvOpe65Ngy3em1QJXWfl7YljuobDwdsZgUM/Il9v33T1Bsi76yp6/2iDQ3NMwx1xEhjCB//4Wr4YMgir1y0pHZOQhIxizxjniQ30kI3O5ZN5BGnte7/IyGSdrAiszcjOEHLgvF19zOWjIyQd61z3bEY9+hjnBV3g6OYekA/E4/4uyRzn/gkgvcP20tfXxCxjfb1u0I1BMP68DJRDpi6yr/vy4K28hhVY1al+tBY7a7wzCwmutXF3Cl4mZMOVlU0QRXa828V2FKwHtrSnDuHwt+BeN4mUQloAjRPam3Gv+7h/CW6duFBMgnqWYhrXrS3VPCtqlyX1xp0y3Kl8f3Qc+z6TFpiNBzX6AwNUD6byGe7IF9L0vyJEy/fvtBL10hpZVbH3j3mfUbSLOEZEuslBKM/vk5z+sXT0Pr8Bydjon3AGURavB5HuX7mt75A4aRujui7AIT89tTlxEhroGwrXtDDs0g3grcqjvd64bcPjboK4kCsdA9NGYlTEMRqtg7MS2/0l9v20wffr3T4HD+ECA8rNoZP5OL6R0ll5cAiz5sFcefrGpfephXGkaPDWmEEGXxRo8HHm90yvmOMhQJ4NY2Gj9+J8AuO3YdhETT3wcE5G5hTrLB4hkBt5p2uibgmYrIzyGVQ9PTCRlcljStUsAReDx3TDfhXe8AwO3FK11sEFyvdKnkFyzR6flXbCJp2BJb3hXHQVYjnd1OhfA8O/F0qD9ktag5ksQ9E9a6QATR9yCnTfhaF3dGsK+nXkkbg0vZEo0IyDaV4HQITWmb75LMNbukZH4W7qYSug1UPSpeq7SgHovEeY6HUAVGjEFxiXtD6HTovFOpx61CroXDulaiVPA6i/upSs/TENoH6rhqjbIxmOcokmmkcS6hdPOTE86owgI9Q78vpTD1kR9UaZVO8doQJKVb9tXpvF4Nnd15B1kifDU6yyzaDo1GOl6Htv5uV3C/XtYjOz7VC9LZF554BPIwu1gv7ABUfmqDZ0DaYesDKQqzk1wdyWoQBLUeEMyttdIFRTGM1OoRBqUX46P4WemkLcPo8fQbESPEeFauGTPUOFauHTHBWqhU9/X+Ec16GawhnuFooK5+fTqFqaOSpU2y3mF1uo7vhzODrbw1FUOLOUt3psQfFKDlpUI+B2s7R5oNwgm+qNf3SoFhDJXoFLhMbbIFPDJpafxdlqtOSLEoz7cx9BepodFuL8+64Zd4Qo9W8h+qdiW5alxZVmbNviYtoz0o1SmytpNH0n5YWFhYWFhYWFhYWFhYWFhQUc/gOKUKVsj+FKEwAAAABJRU5ErkJggg=='
        }
    },
    methods:{
      add(){
        if (this.firstname === "" || this.lastname === ""){
          alert("Please right something");
        }else{
            var id = '';
            while (id.length < 8) {
                var b = Math.floor((Math.random() * 100000));
                id += b;
            }
            var obj = {
                k_number: 'k0' + id.slice(0, 8),
                name: this.firstname + " " + this.lastname,
                pic:this.pic
            }
          this.students.push(obj);
          this.reset();
        }
      },
      reset(){
          this.firstname = "";
          this.lastname = "";
      }
    }
}
</script>

<style scoped>
.bg-silver{
    background-color: #222;
}
.text-silver{
    color: #666;
    font-weight: normal;
}

.inputField{
    border: 0px;
    font-size: 2em;
    color: black;
    border-bottom: 1px solid #555;
}

.btnStep{
    border-radius: 50px;
}
</style>