<template>
    
    <div class="row container-fluid mt-4 d-flex justify-content-center"
     >

        <div class="col-lg-10 bg-dark d-flex justify-content-center sticky-top mb-3">
            <!-- Research -->
            <div class="input-group col-lg-3 mb-3 mt-3" v-show="editPanel">
                <button class="btn btn-danger input-group-prepend"
                @click.prevent="hideEditPanel()">
                    Close
                </button>
                <input type="text" class="form-control text-center"
                v-model="fullName" placeholder="Enter Full Name"
                    aria-label="Recipient's username" aria-describedby="basic-addon2">
                <button class="btn btn-success input-group-append"
                @click.prevent="editItem">
                    Validate
                </button>
            </div>
            <!-- End Research -->
        </div>

        <div class="col-lg-10 bg-light pt-3" style="border-radius:50px;">
            <table class="table text-center">

                <tr>
                    <th class="py-2 enTete">#</th>
                    <th class="py-2 enTete">K-number</th>
                    <th class="py-2 enTete">Full Name</th>
                    <th class="py-2 enTete">Actions</th>
                </tr>

                <tr v-for="(x, key) in students" :key="key">
                    <td>{{key+1}}</td>
                    <td>{{x.k_number}}</td>
                    <td>{{x.name}}</td>
                    <td>
                        <button class="btn btn-primary" style="border-radius:50px;"
                        @click.prevent="showEditPanel(x.name, key)">
                            Edit</button>
                        &nbsp;
                        <button class="btn btn-danger" style="border-radius:50px;"
                        @click.prevent="deleteItem(key)">
                            Delete</button>
                    </td>
                </tr>

            </table>

        </div>

    </div>

</template>

<script>
export default {
    name:'DataAccess',
    props:['students'],
    data(){
        return{
            editPanel:false,
            keyToEdit:0,
            fullName:''
        }
    },
    methods:{
        showEditPanel(value,key){
            this.fullName = value;
            this.keyToEdit = key;
            this.editPanel = true;
        },
        hideEditPanel(){
            this.editPanel = !this.editPanel;
        },
        deleteItem(key){
            this.students.splice(key,1);
        },
        editItem(){
            this.students[this.keyToEdit].name= this.fullName;
        }
        
    }
    
}
</script>

<style scoped>
th, td{
    border:none;
    font-size: 1.2em;
}

.enTete{
    border-bottom: 1px solid black;
}
</style>