<template>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" 
        data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" 
        aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <!-- Name of the app -->
            <a class="navbar-brand" href="#/">
                <span class="h1 text-primary">Registration App</span>
            </a>
            <!-- end Name of the app -->

            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item">
                <a class="nav-link" href="#/">
                    <span class="link">Registration</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#/Students">
                    <span class="link">Students</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#/DataAccess">
                    <span class="link">Data Access</span>
                </a>
            </li>
            </ul>
            
        </div>
    </nav>

</template>

<script>
export default {
    name: "navidationbtn"
}
</script>

<style scoped>

.link{
    font-size: 1.5em;
    color:black;
    padding: 10px;
}

.link:hover{
    color:white;
    background-color: dodgerblue;
    border-radius: 35px;
}

</style>