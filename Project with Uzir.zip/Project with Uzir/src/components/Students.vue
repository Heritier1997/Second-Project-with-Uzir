<template>
    
    <div class="container-fluid d-flex justify-content-center mt-3">

        <div class="row col-md-8 py-3 d-flex justify-content-center" 
        style="border-radius:50px; flex-direction:row;">
            
            <div class="col-lg-8 sticky-top bg-dark mb-3">                
                <!-- Research -->
                <div class="d-none input-group mb-3 mt-3">
                    <input type="text" class="form-control text-center" 
                    placeholder="Enter a K-number" 
                    aria-label="Recipient's username" aria-describedby="basic-addon2">
                    <button class="btn btn-success input-group-append">
                        Search
                    </button>
                </div>   
                <!-- End Research -->

                <!-- Pagination -->
                <span class="text-white float-left p-2 font-weight-bold">{{nomberOfStudent}} Students</span>
                
                <div class="d-flex justify-content-end">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination py-1">
                            <li class="page-item"><a class="page-link bg-dark border-0
                             text-white"
                             href="#" @click.prevent="previousMethod">Previous</a></li>
                            
                            <span class="" v-for="(x,key) in students.slice(0, paginationMethod)"
                             :key="key">
                                <li class="page-item">
                                    <a class="page-link bg-dark border-0
                                    text-white"  href="#"
                                    @click.prevent="getPage(key)">{{key+1}}</a></li>
                            </span>

                            <li class="page-item"><a class="page-link bg-dark border-0
                             text-white "
                             href="#" @click.prevent="nextMethod">Next</a></li>
                        </ul>
                    </nav>
                </div>
                <!-- End Pagination -->

            </div>

            <!-- ID Card start -->
            <div class="card col-lg-8 mt-0" 
            v-for="(x,key) in students.slice(previous, nextious)" :key="key">

                <!-- Header -->
                <div class="card-header bg-white border-0 d-flex" style="flex-direction: row;">
                    
                    <div class="row text-primary" style="width: 100%;">
                        <!-- Picture of the student -->
                        <div class="col-4">
                            <img :src="x.pic" 
                            class="img-fluid rounded-circle"
                            style="width: 100px; height: 100px;" />
                        </div>
                        <!-- End picture of the student -->
                        
                        <!-- Name of the University -->
                        <div class="col-8 text-center">
                            <h1 class="text-primary h1"><u>Kirwood</u></h1>
                            <h5 class="text-primary">COMMUNITY&nbsp;COLLEGE</h5>
                        </div>
                        <!-- ENd Name of University -->

                    </div>
                </div>
                <!-- End header -->

                <!-- Body -->
                <span class="d-none">{{fristTime}}</span>
                <div class="card-body bg-white border-0 d-flex" style="flex-direction: row;">
                    <div class="row" style="width: 100%;">
                        <div class="col-12">
                            <h3>{{x.name}}</h3>
                            <h6><b>STUDENT</b></h6>
                            <h6><b>{{x.k_number}}</b></h6>
                        </div>
                    </div>
                </div>
                <!-- End Body -->
            </div>
        </div>
        <!-- End ID Card  -->

    </div>
    
</template>

<script>
export default {
    name: 'Students',
    props: ['students'],
    data(){
        return{
            pagination:[],
            previous:0,
            nextious:3
        }
    },
    computed:{
        nomberOfStudent(){
            return this.students.length;
        },
        paginationMethod(){
            var a = (this.students.length/3)
            var b = a - Math.floor(this.students.length/3);
            if (b>0){
                a+=1
            }
            return a;
        },
        StudentMethod(){
            return this.students.length/5; 
        },
        fristTime(){
            this.addPage();
            return 0;
        },
    },
    methods:{
        addPage(){
            var item = 0;
            for (let i = 0; i < this.students.length/3; i++) {
                var obj = {
                    prev:item,
                    next:item+3
                }
                this.pagination.push(obj);
                item+=3;

            }
        },
        getPage(key){
            this.previous = this.pagination[key].prev;
            this.nextious = this.pagination[key].next;
            // alert(this.previous + " --- " + this.nextious);
        },
        previousMethod(){
            if (this.previous<=0){
                this.previous = 0;
                this.nextious = 3;
            }else{
                this.previous -=3;
                this.nextious -=3;
            }
        },
        nextMethod(){
            var a = this.students.length;
            if (this.nextious>=a){
                this.previous = Number(a-3);
                this.nextious = a;
            }else{
                this.previous +=3;
                this.nextious +=3;
            }
        }
        
    }
}
</script>