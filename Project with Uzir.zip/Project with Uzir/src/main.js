import Vue from 'vue';
import VueRouter from 'vue-router';

import App from './App.vue';
import "bootstrap";
import {library} from "@fortawesome/fontawesome-svg-core";

import "bootstrap/dist/css/bootstrap.css";
import "animate.css/animate.css";

import{
  faShoppingCart,
  faDollarSign
} from "@fortawesome/free-solid-svg-icons";

library.add(faShoppingCart, faDollarSign);

Vue.use(VueRouter);
Vue.config.productionTip = false;

import Students from './components/Students.vue';
import DataAccess from './components/DataAccess.vue';
import Registration from './components/Registration.vue'

const router = new VueRouter({
  routes:[
    {
      path: "/Students",
      component: Students 
    },
    {
      path: "/DataAccess",
      component: DataAccess 
    },
    {
      path: "*",
      component: Registration
    },
  ]
});

new Vue({
  render: h => h(App),
  router
}).$mount('#app')
